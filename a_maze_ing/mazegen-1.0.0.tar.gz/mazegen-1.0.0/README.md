_This project has been created as part
of the 42 curriculum by macarrara[,jhenriqu]_

**Description**

• This is a Maze generator created as part of the 42 curriculum. The project uses Depth-First Search(DFS) to generate a Maze with parameters defined in its configuration file named "config.txt", it will then display it in the terminal and be able to interract with the maze. It will also output a file that contains the solution path as well as the maze generated encoded in hexadecimal values. 



**Instrcutions**
The project directory contains a sub-directory named 'mazegen', containing the maze generation and manipulation scripts, a_maze_ing.py script used to start the program, a config.txt file that contains the maze's parameters, pyproject.toml for building the mazegen package, 

# Maze configuration file
WIDTH=15
HEIGHT=15
ENTRY=0,0
EXIT=14,14
OUTPUT_FILE=maze.txt
PERFECT=False
#SEED=42


**Resources**

section listing classic references related to the topic (documentation, articles, tutorials, etc.), as well as a description of how AI was used —
specifying for which tasks and which parts of the project.


• The complete structure and format of your config file.



• The maze generation algorithm you chose. -> DFS DFS (recursive backtracking)
• Why you chose this algorithm. -> there is alot of info about ir
• What part of your code is reusable, and how.-> mazegen parsing, writer and display are all reusable
• Your team and project management with:
◦ The roles of each team member. 

marco parsing display maze generation, display readme, UI
joel maze generation, display, writer, pyproject.toml, readme


◦ Your anticipated planning and how it evolved until the end
we delagated individual work
he worked on the parsing first
i work on the perfect/nonperfect maze generation
then worked together on the display i worked on the display marco on the UI and with everybreakthrough we unified work(to avoid big discrepancies in the work)

i worked on the canvas to display the both the maze with the path and without the path, marco finished ironing out the kinks

then he worked on finalizing maze coloring, UI,

i did the package for the maze generation, writer, and ironing out final kinks

permission issues, writer overwriting files, non perfect maze


◦ What worked well and what could be improved
it worked well that we each picked up on the work the prvious has done and moving the project forward
working simultanouisly caused syncronizqation "issue" and I say issues because we started seeing that we worked on the same task, at the same time and modified the code in a way that the other person then could not continuou with its work since implementing the changes was conflicting with the other's work

◦ Have you used any specific tools? Which ones?
AI with assistance in debugging, finding error 


mazegen installation instructions
 - insstall build tools: pip install build
 - build package python3 -m build
 - install locally pip install dist/mazegen-1.0.0-py3-none-any.whl

 modify makefile to check module installation



